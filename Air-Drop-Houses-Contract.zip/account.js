module.exports = {
  address: "0x3c3d8b9A40060E82FcE0357Bf833E28141Bf5289",
  privateKey:
    "6e22bd008464f3c6a045b711fdc696d5afab7e95594ef299013a930a1a916f68",
  url: "https://rinkeby.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161",
};
